package com.cg.oops.Q5;

import com.cg.oops.Q5.*;


public class Main {
	public static void main(String[] args) {
		Shape obj= new Cube();
		obj.draw();
	}

}

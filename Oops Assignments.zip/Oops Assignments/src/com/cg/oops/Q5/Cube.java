package com.cg.oops.Q5;

public class Cube extends Shape {
	@Override
	void draw() {

System.out.println("It is in cube shape");
		
	}
	
}

package com.cg.oops.Q5;

abstract class Shape{
	abstract void draw();
}
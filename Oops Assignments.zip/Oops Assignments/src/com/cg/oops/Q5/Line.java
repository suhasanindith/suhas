package com.cg.oops.Q5;

public class Line extends Shape {
	@Override
	void draw() {
		System.out.println("It is in straigth line");
	}

}

package com.cg.oops.Q3;

public class Account {
	float deposite=1000;
	public float get_total_amt() {
		return deposite;
	}

}

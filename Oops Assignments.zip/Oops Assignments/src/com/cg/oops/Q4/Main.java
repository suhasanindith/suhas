package com.cg.oops.Q4;

//a class is either public or default
//final class is not supported for inheritance ,when we cant inherit it then hoe provide implementation for abstract method ,
//abstract class not a final
public abstract class Main {
	 //if a class contain abstract method then class must be abstract
		public abstract void meth();
}

package com.cg.assignments;

import java.util.Scanner;

public class Searching {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int []a = new int[15];
		int i;
		for( i=0;i<15;i++)
		{
			a[i] = sc.nextInt();
			
		}
		int num = sc.nextInt();
		for( i =0 ; i<15; i++)
		{
			if(num==a[i])
			{
				System.out.println("yes");
				break;
			}
		}
		if(i==15)
			System.out.println("no");
		
	}

}

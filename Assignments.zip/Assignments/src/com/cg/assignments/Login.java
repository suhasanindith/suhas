package com.cg.assignments;

import java.util.Scanner;

public class Login {
	public static void main(String[] args ) {
		Scanner sc= new Scanner(System.in);
		int i ;
		for(i=0;i<3;i++)
		{
			System.out.println("Enter Login name: ");
			String name = sc.nextLine();
			System.out.println("Enter Password: ");
			String password = sc.nextLine();
			
			if(name.equals("Suhas") && password.equals("Hello123"))
			{
				System.out.println("Welcome");
				break;
			}
		}
		if (i==3)
			System.out.println("Contact Admin");
	}

}

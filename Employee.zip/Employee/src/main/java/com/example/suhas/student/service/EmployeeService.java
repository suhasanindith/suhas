package com.example.suhas.student.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.suhas.student.model.EmployeeModel;
import com.example.suhas.student.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository repo;
	
	public ArrayList<EmployeeModel> findall(){
		return (ArrayList<EmployeeModel>)repo.findAll();
		
	}

}

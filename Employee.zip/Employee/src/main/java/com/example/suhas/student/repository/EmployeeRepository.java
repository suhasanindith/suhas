package com.example.suhas.student.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.suhas.student.model.EmployeeModel;

@Repository
public interface EmployeeRepository  extends CrudRepository<EmployeeModel, String>{

}
